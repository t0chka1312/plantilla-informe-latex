Comandos a ejecutar:

latexmk -pdf plantilla.tex -pvc -> Para compilar y ver cambios

En caso de error:

latexmk -C
latexmk -pdf plantilla.tex -> Después con la opción -pvc
